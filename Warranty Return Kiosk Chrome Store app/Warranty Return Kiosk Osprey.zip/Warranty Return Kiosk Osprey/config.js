window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "Warranty Return Kiosk Osprey",
   "homepage": "https://www.tervis.com/store-return?storeid=1010",
   "enableNavBttns": false,
   "enableHomeBttn": false,
   "enableReloadBttn": false,
   "enableLogoutBttn": false,
   "kioskEnabled": true
};