window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "Warranty Return Kiosk Ft Myers",
   "homepage": "https://www.tervis.com/store-return?storeid=1040",
   "enableNavBttns": false,
   "enableHomeBttn": false,
   "enableReloadBttn": false,
   "enableLogoutBttn": false,
   "kioskEnabled": true
};